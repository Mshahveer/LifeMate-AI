package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.BudgetFeatureColor

data class BudgetItem(
  val id: Long,
  val categoryEn: String,
  val categoryUr: String,
  val amount: Double,
  val isIncome: Boolean,
)

@Composable
fun BudgetPlannerSheet(
  language: AppLanguage,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val transactions = remember {
    mutableStateListOf(
      BudgetItem(1, "Freelance Client", "فری لانس پراجیکٹ", 45000.0, true),
      BudgetItem(2, "House Rent & Utility", "گھر کا کرایہ و بلز", 18000.0, false),
      BudgetItem(3, "Online Course & Skills", "آن لائن کورس فیس", 3500.0, false),
      BudgetItem(4, "Groceries & Food", "راشن و گروسری", 9200.0, false),
    )
  }

  var amountText by remember { mutableStateOf("") }
  var categoryText by remember { mutableStateOf("Food / کھانا") }
  var isIncome by remember { mutableStateOf(false) }

  val totalIncome = transactions.filter { it.isIncome }.sumOf { it.amount }
  val totalExpense = transactions.filter { !it.isIncome }.sumOf { it.amount }
  val netBalance = totalIncome - totalExpense

  val categories = if (language.isUrdu) {
    listOf("کھانا و راشن", "بلز و کرایہ", "کورس و کتابیں", "فری لانس آمدن", "متفرق")
  } else {
    listOf("Food & Groceries", "Bills & Rent", "Courses & Books", "Freelance Income", "Other")
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(BudgetFeatureColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.AccountBalanceWallet,
            contentDescription = null,
            tint = BudgetFeatureColor,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (language.isUrdu) "بجٹ پلانر" else "Budget Planner",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (language.isUrdu) "آمدنی، اخراجات اور بچت کا انتظام" else "Smart money & savings manager",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("budget_sheet_close_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close")
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Summary Cards (Income, Expense, Balance)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Balance
      Card(
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BudgetFeatureColor.copy(alpha = 0.1f))
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text(
            text = if (language.isUrdu) "کل بیلنس" else "Net Balance",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Rs ${"%,.0f".format(netBalance)}",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = BudgetFeatureColor
          )
        }
      }

      // Income
      Card(
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.1f))
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color(0xFF047857), modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = if (language.isUrdu) "آمدن" else "Income",
              fontSize = 11.sp,
              color = Color(0xFF047857)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Rs ${"%,.0f".format(totalIncome)}",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = Color(0xFF047857)
          )
        }
      }

      // Expense
      Card(
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.1f))
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFFB91C1C), modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = if (language.isUrdu) "خرچ" else "Expense",
              fontSize = 11.sp,
              color = Color(0xFFB91C1C)
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Rs ${"%,.0f".format(totalExpense)}",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = Color(0xFFB91C1C)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Quick add entry
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          FilterChip(
            selected = !isIncome,
            onClick = { isIncome = false },
            label = { Text(if (language.isUrdu) "خرچ (Expense)" else "Expense", fontSize = 12.sp) }
          )
          FilterChip(
            selected = isIncome,
            onClick = { isIncome = true },
            label = { Text(if (language.isUrdu) "آمدن (Income)" else "Income", fontSize = 12.sp) }
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it.filter { char -> char.isDigit() || char == '.' } },
            placeholder = { Text(if (language.isUrdu) "رقم (مثلاً 1500)" else "Amount (e.g. 1500)", fontSize = 12.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(10.dp),
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .testTag("budget_amount_input")
          )
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull()
              if (amt != null && amt > 0) {
                transactions.add(
                  0,
                  BudgetItem(
                    id = System.currentTimeMillis(),
                    categoryEn = if (isIncome) "Income Entry" else "Expense Entry",
                    categoryUr = if (isIncome) "آمدنی اندراج" else "خرچ اندراج",
                    amount = amt,
                    isIncome = isIncome
                  )
                )
                amountText = ""
              }
            },
            enabled = amountText.toDoubleOrNull() != null,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BudgetFeatureColor),
            modifier = Modifier.testTag("add_budget_entry_button")
          ) {
            Icon(Icons.Default.Add, contentDescription = "Add")
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (language.isUrdu) "شامل کریں" else "Add", fontSize = 12.sp)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Transactions list
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(6.dp),
      modifier = Modifier.weight(1f, fill = false)
    ) {
      items(transactions, key = { it.id }) { item ->
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surface,
          tonalElevation = 1.dp,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (item.isIncome) Color(0xFF10B981) else Color(0xFFEF4444))
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (language.isUrdu) item.categoryUr else item.categoryEn,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
              )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "${if (item.isIncome) "+" else "-"} Rs ${"%,.0f".format(item.amount)}",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (item.isIncome) Color(0xFF047857) else Color(0xFFB91C1C)
              )
              IconButton(
                onClick = { transactions.remove(item) },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(
                  Icons.Default.DeleteOutline,
                  contentDescription = "Delete",
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
              }
            }
          }
        }
      }
    }
  }
}
