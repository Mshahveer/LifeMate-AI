package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.SkillsFeatureColor

data class SkillItem(
  val id: String,
  val titleEn: String,
  val titleUr: String,
  val categoryEn: String,
  val categoryUr: String,
  val durationEn: String,
  val durationUr: String,
  val levelEn: String,
  val levelUr: String,
  val potentialEn: String,
  val potentialUr: String,
  val summaryEn: String,
  val summaryUr: String,
)

@Composable
fun LearnSkillsSheet(
  language: AppLanguage,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val skills = remember {
    listOf(
      SkillItem(
        id = "ai_prompting",
        titleEn = "AI Prompt Engineering",
        titleUr = "اے آئی پرامپٹ انجینئرنگ",
        categoryEn = "Artificial Intelligence",
        categoryUr = "مصنوعی ذہانت",
        durationEn = "3 Weeks",
        durationUr = "۳ ہفتے",
        levelEn = "Beginner",
        levelUr = "ابتدائی",
        potentialEn = "$25 - $60 / hr",
        potentialUr = "۲۵ سے ۶۰ ڈالر فی گھنٹہ",
        summaryEn = "Master crafting precise context and system prompts for LLMs and automated workflows.",
        summaryUr = "اے آئی ماڈلز سے بہترین نتائج حاصل کرنے اور آٹومیشن کے لیے درست پرامپٹ بنانا سیکھیں۔"
      ),
      SkillItem(
        id = "web_dev",
        titleEn = "Modern Web & App Development",
        titleUr = "جدید ویب اور موبائل ایپ ڈویلپمنٹ",
        categoryEn = "Software & Tech",
        categoryUr = "سافٹ ویئر اور ٹیک",
        durationEn = "8 Weeks",
        durationUr = "۸ ہفتے",
        levelEn = "Intermediate",
        levelUr = "درمیانی سطح",
        potentialEn = "$30 - $80 / hr",
        potentialUr = "۳۰ سے ۸۰ ڈالر فی گھنٹہ",
        summaryEn = "Build responsive websites and modern apps using HTML/CSS/JavaScript and Kotlin/React.",
        summaryUr = "ویب سائٹس اور اینڈرائڈ ایپس بنانا سیکھ کر عالمی کلائنٹس کے ساتھ کام کریں۔"
      ),
      SkillItem(
        id = "video_editing",
        titleEn = "Short-Form Video Editing",
        titleUr = "شارٹ ویڈیو ایڈیٹنگ اور ریلز",
        categoryEn = "Content Creation",
        categoryUr = "میڈیا و کانٹینٹ",
        durationEn = "4 Weeks",
        durationUr = "۴ ہفتے",
        levelEn = "Beginner to Pro",
        levelUr = "ابتدائی تا ماہر",
        potentialEn = "$15 - $50 / video",
        potentialUr = "۱۵ سے ۵۰ ڈالر فی ویڈیو",
        summaryEn = "Create engaging Reels, TikToks, and YouTube Shorts with CapCut and Premiere Pro.",
        summaryUr = "سوشل میڈیا کے لیے دلکش ویڈیوز، سب ٹائٹلز اور اینیمیشنز تیار کرنا سیکھیں۔"
      ),
      SkillItem(
        id = "ui_ux",
        titleEn = "UI/UX & Mobile Design (Figma)",
        titleUr = "یو آئی اور یو ایکس ڈیزائن (فگما)",
        categoryEn = "Design & Creative",
        categoryUr = "تخلیقی ڈیزائن",
        durationEn = "5 Weeks",
        durationUr = "۵ ہفتے",
        levelEn = "All Levels",
        levelUr = "تمام درجات",
        potentialEn = "$20 - $70 / hr",
        potentialUr = "۲۰ سے ۷۰ ڈالر فی گھنٹہ",
        summaryEn = "Design beautiful user interfaces, wireframes, and prototypes for digital applications.",
        summaryUr = "خوبصورت اور جدید موبائل ایپس اور ویب اسکرینز کے پروٹو ٹائپ ڈیزائن کریں۔"
      ),
      SkillItem(
        id = "freelance_pitch",
        titleEn = "Freelance Client Acquisition",
        titleUr = "فری لانس کلائنٹ حاصل کرنے کا طریقہ",
        categoryEn = "Business & Sales",
        categoryUr = "کاروبار اور سیلز",
        durationEn = "2 Weeks",
        durationUr = "۲ ہفتے",
        levelEn = "Essential",
        levelUr = "لازمی مہارت",
        potentialEn = "High Conversion",
        potentialUr = "کلائنٹ منظوری",
        summaryEn = "Write winning proposals on Upwork/Fiverr and communicate with international buyers.",
        summaryUr = "بین الاقوامی خریداروں کے لیے پرکشش پروپوزل اور کمیونیکیشن کے اصول سیکھیں۔"
      )
    )
  }

  val skillStatusMap = remember {
    mutableStateMapOf<String, String>().apply {
      put("ai_prompting", "In Progress")
      put("freelance_pitch", "Completed")
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(SkillsFeatureColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.School,
            contentDescription = null,
            tint = SkillsFeatureColor,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (language.isUrdu) "مہارتیں سیکھیں" else "High-Income Skills",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (language.isUrdu) "مارکیٹ میں سب سے زیادہ طلب شدہ اسکلز" else "Top demanded career skills",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("skills_sheet_close_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close")
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    Text(
      text = if (language.isUrdu) "اپنا کورس منتخب کریں اور پروگریس ٹریک کریں:" else "Select a track to start learning:",
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(8.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.weight(1f, fill = false)
    ) {
      items(skills, key = { it.id }) { skill ->
        val currentStatus = skillStatusMap[skill.id] ?: "Not Started"
        
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = if (language.isUrdu) skill.titleUr else skill.titleEn,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              
              // Status Badge
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = when (currentStatus) {
                  "Completed" -> Color(0xFF10B981).copy(alpha = 0.15f)
                  "In Progress" -> SkillsFeatureColor.copy(alpha = 0.15f)
                  else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                },
                modifier = Modifier.clickable {
                  // Cycle status on tap
                  skillStatusMap[skill.id] = when (currentStatus) {
                    "Not Started" -> "In Progress"
                    "In Progress" -> "Completed"
                    else -> "Not Started"
                  }
                }
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                  Icon(
                    imageVector = when (currentStatus) {
                      "Completed" -> Icons.Default.CheckCircle
                      "In Progress" -> Icons.Default.PlayArrow
                      else -> Icons.Default.Star
                    },
                    contentDescription = null,
                    tint = when (currentStatus) {
                      "Completed" -> Color(0xFF10B981)
                      "In Progress" -> SkillsFeatureColor
                      else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    modifier = Modifier.size(12.dp)
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = if (language.isUrdu) {
                      when (currentStatus) {
                        "Completed" -> "مکمل"
                        "In Progress" -> "جاری ہے"
                        else -> "شروع کریں"
                      }
                    } else currentStatus,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = when (currentStatus) {
                      "Completed" -> Color(0xFF047857)
                      "In Progress" -> SkillsFeatureColor
                      else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
              text = if (language.isUrdu) skill.summaryUr else skill.summaryEn,
              fontSize = 13.sp,
              lineHeight = 18.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${if (language.isUrdu) "دورانیہ: " else "Time: "}${if (language.isUrdu) skill.durationUr else skill.durationEn}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = "${if (language.isUrdu) "آمدنی: " else "Potential: "}${if (language.isUrdu) skill.potentialUr else skill.potentialEn}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = SkillsFeatureColor
              )
            }
          }
        }
      }
    }
  }
}
