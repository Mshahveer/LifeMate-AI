package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.FeatureType
import com.example.model.Translations
import com.example.ui.components.AiAssistantSheet
import com.example.ui.components.BudgetPlannerSheet
import com.example.ui.components.DailyGoalsSheet
import com.example.ui.components.EarnOnlineSheet
import com.example.ui.components.LearnSkillsSheet
import com.example.ui.components.ScamCheckerSheet
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  modifier: Modifier = Modifier,
) {
  var currentLanguage by remember { mutableStateOf(AppLanguage.ENGLISH) }
  var selectedFeature by remember { mutableStateOf<FeatureType?>(null) }
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()

  val layoutDirection = if (currentLanguage.isUrdu) LayoutDirection.Rtl else LayoutDirection.Ltr

  // Handle hardware / gesture back button
  BackHandler(enabled = selectedFeature != null) {
    scope.launch {
      sheetState.hide()
      selectedFeature = null
    }
  }

  CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
    Scaffold(
      modifier = modifier
        .fillMaxSize()
        .testTag("home_screen_scaffold"),
      containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // 1. Top Bar & Language Selector (Spans both columns)
        item(span = { GridItemSpan(2) }) {
          TopHeaderSection(
            currentLanguage = currentLanguage,
            onLanguageChange = { currentLanguage = it },
          )
        }

        // 2. Daily Wisdom Banner (Spans both columns)
        item(span = { GridItemSpan(2) }) {
          DailyWisdomBanner(language = currentLanguage)
        }

        // 3. Section Title (Spans both columns)
        item(span = { GridItemSpan(2) }) {
          SectionHeader(language = currentLanguage)
        }

        // 4. The 6 Main Feature Buttons / Cards
        items(FeatureType.entries.toTypedArray(), key = { it.name }) { feature ->
          FeatureButtonCard(
            feature = feature,
            language = currentLanguage,
            onClick = {
              selectedFeature = feature
            }
          )
        }

        // 5. Trust and Security Footer (Spans both columns)
        item(span = { GridItemSpan(2) }) {
          TrustFooter(language = currentLanguage)
        }
      }

      // Feature Interactive Bottom Sheet Modal
      if (selectedFeature != null) {
        ModalBottomSheet(
          onDismissRequest = {
            scope.launch {
              sheetState.hide()
              selectedFeature = null
            }
          },
          sheetState = sheetState,
          containerColor = MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        ) {
          when (selectedFeature) {
            FeatureType.AI_ASSISTANT -> AiAssistantSheet(
              language = currentLanguage,
              onDismiss = {
                scope.launch {
                  sheetState.hide()
                  selectedFeature = null
                }
              }
            )
            FeatureType.LEARN_SKILLS -> LearnSkillsSheet(
              language = currentLanguage,
              onDismiss = {
                scope.launch {
                  sheetState.hide()
                  selectedFeature = null
                }
              }
            )
            FeatureType.EARN_ONLINE -> EarnOnlineSheet(
              language = currentLanguage,
              onDismiss = {
                scope.launch {
                  sheetState.hide()
                  selectedFeature = null
                }
              }
            )
            FeatureType.SCAM_CHECKER -> ScamCheckerSheet(
              language = currentLanguage,
              onDismiss = {
                scope.launch {
                  sheetState.hide()
                  selectedFeature = null
                }
              }
            )
            FeatureType.DAILY_GOALS -> DailyGoalsSheet(
              language = currentLanguage,
              onDismiss = {
                scope.launch {
                  sheetState.hide()
                  selectedFeature = null
                }
              }
            )
            FeatureType.BUDGET_PLANNER -> BudgetPlannerSheet(
              language = currentLanguage,
              onDismiss = {
                scope.launch {
                  sheetState.hide()
                  selectedFeature = null
                }
              }
            )
            null -> Unit
          }
        }
      }
    }
  }
}

@Composable
private fun TopHeaderSection(
  currentLanguage: AppLanguage,
  onLanguageChange: (AppLanguage) -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // App Branding (Logo + Titles)
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
              Brush.linearGradient(
                listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6))
              )
            )
            .shadow(4.dp, RoundedCornerShape(14.dp)),
          contentAlignment = Alignment.Center,
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_lifemate_logo),
            contentDescription = "LifeMate AI Logo",
            modifier = Modifier
              .size(38.dp)
              .clip(RoundedCornerShape(10.dp))
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = Translations.appTitle(currentLanguage),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.ExtraBold,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = Color(0xFFF59E0B),
              modifier = Modifier.size(16.dp)
            )
          }
          Text(
            text = Translations.appTagline(currentLanguage),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
          )
        }
      }

      // Language Switcher Toggle Pill
      LanguageTogglePill(
        currentLanguage = currentLanguage,
        onLanguageChange = onLanguageChange,
      )
    }
  }
}

@Composable
private fun LanguageTogglePill(
  currentLanguage: AppLanguage,
  onLanguageChange: (AppLanguage) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(24.dp),
    color = MaterialTheme.colorScheme.surfaceVariant,
    tonalElevation = 2.dp,
    modifier = modifier.testTag("language_toggle_pill")
  ) {
    Row(
      modifier = Modifier.padding(3.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // English Button
      val isEnglish = currentLanguage == AppLanguage.ENGLISH
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(
            if (isEnglish) MaterialTheme.colorScheme.primary else Color.Transparent
          )
          .clickable { onLanguageChange(AppLanguage.ENGLISH) }
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .testTag("lang_en_button"),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "EN 🇬🇧",
          fontSize = 12.sp,
          fontWeight = if (isEnglish) FontWeight.Bold else FontWeight.Normal,
          color = if (isEnglish) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Urdu Button
      val isUrdu = currentLanguage == AppLanguage.URDU
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(
            if (isUrdu) MaterialTheme.colorScheme.primary else Color.Transparent
          )
          .clickable { onLanguageChange(AppLanguage.URDU) }
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .testTag("lang_ur_button"),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "اردو 🇵🇰",
          fontSize = 12.sp,
          fontWeight = if (isUrdu) FontWeight.Bold else FontWeight.Normal,
          color = if (isUrdu) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

@Composable
private fun DailyWisdomBanner(
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
    )
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.Lightbulb,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(22.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column {
        Text(
          text = Translations.dailyTipTitle(language),
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = Translations.dailyTip(language),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          lineHeight = 18.sp
        )
      }
    }
  }
}

@Composable
private fun SectionHeader(
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = Translations.servicesHeader(language),
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )
    Text(
      text = Translations.servicesSubHeader(language),
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}

@Composable
private fun FeatureButtonCard(
  feature: FeatureType,
  language: AppLanguage,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .height(180.dp)
      .clip(RoundedCornerShape(20.dp))
      .clickable(onClick = onClick)
      .testTag(feature.testTag),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(14.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top row: Icon and Badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(feature.accentColor.copy(alpha = 0.12f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = feature.icon,
            contentDescription = feature.getTitle(language),
            tint = feature.accentColor,
            modifier = Modifier.size(26.dp)
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = feature.accentColor.copy(alpha = 0.1f)
        ) {
          Text(
            text = feature.getBadge(language),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = feature.accentColor,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }
      }

      // Middle: Titles
      Column {
        Text(
          text = feature.getTitle(language),
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
          text = feature.getDescription(language),
          fontSize = 11.sp,
          lineHeight = 15.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2
        )
      }

      // Bottom Row: Action Prompt
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = Translations.openButton(language),
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold,
          color = feature.accentColor
        )
        Box(
          modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(feature.accentColor.copy(alpha = 0.1f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = feature.accentColor,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }
  }
}

@Composable
private fun TrustFooter(
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = Icons.Default.VerifiedUser,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
      modifier = Modifier.size(16.dp)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = Translations.safetyGuarantee(language),
      fontSize = 11.sp,
      color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
      textAlign = TextAlign.Center
    )
  }
}
