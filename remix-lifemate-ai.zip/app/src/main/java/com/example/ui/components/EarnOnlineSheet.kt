package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.EarnFeatureColor
import kotlin.math.roundToInt

@Composable
fun EarnOnlineSheet(
  language: AppLanguage,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var weeklyHours by remember { mutableFloatStateOf(15f) }
  var hourlyRate by remember { mutableFloatStateOf(15f) }

  val monthlyEarningsUsd = (weeklyHours * hourlyRate * 4).roundToInt()
  val monthlyEarningsPkr = monthlyEarningsUsd * 280 // approx PKR rate

  Column(
    modifier = modifier
      .fillMaxWidth()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(EarnFeatureColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.TrendingUp,
            contentDescription = null,
            tint = EarnFeatureColor,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (language.isUrdu) "آن لائن کمائیں" else "Earn Online",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (language.isUrdu) "تصدیق شدہ اور محفوظ طریقے" else "Verified legitimate income streams",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("earn_sheet_close_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close")
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Interactive Earnings Estimator
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = EarnFeatureColor.copy(alpha = 0.08f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Savings,
            contentDescription = null,
            tint = EarnFeatureColor,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (language.isUrdu) "آمدنی کیلکولیٹر (ماہانہ تخمینہ)" else "Income Calculator (Monthly Estimate)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = EarnFeatureColor
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Hours slider
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = if (language.isUrdu) "ہفتہ وار گھنٹے:" else "Weekly Hours:",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "${weeklyHours.roundToInt()} ${if (language.isUrdu) "گھنٹے" else "hrs/week"}",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = EarnFeatureColor
          )
        }
        Slider(
          value = weeklyHours,
          onValueChange = { weeklyHours = it },
          valueRange = 5f..40f,
          steps = 7,
          colors = SliderDefaults.colors(
            thumbColor = EarnFeatureColor,
            activeTrackColor = EarnFeatureColor,
          )
        )

        // Rate slider
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = if (language.isUrdu) "فی گھنٹہ معاوضہ:" else "Hourly Rate ($):",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "$${hourlyRate.roundToInt()} / hr",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = EarnFeatureColor
          )
        }
        Slider(
          value = hourlyRate,
          onValueChange = { hourlyRate = it },
          valueRange = 5f..50f,
          steps = 9,
          colors = SliderDefaults.colors(
            thumbColor = EarnFeatureColor,
            activeTrackColor = EarnFeatureColor,
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surface,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = if (language.isUrdu) "متوقع ماہانہ آمدنی:" else "Estimated Monthly Potential:",
              fontSize = 12.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "$$monthlyEarningsUsd USD",
              fontSize = 24.sp,
              fontWeight = FontWeight.ExtraBold,
              color = EarnFeatureColor
            )
            Text(
              text = "≈ Rs ${"%,d".format(monthlyEarningsPkr)} PKR",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Top Legitimate Channels
    Text(
      text = if (language.isUrdu) "حقیقی آن لائن راستے:" else "Legitimate Income Channels:",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
    )
    Spacer(modifier = Modifier.height(8.dp))

    val channels = if (language.isUrdu) {
      listOf(
        "فری لانسنگ مارکیٹس (Upwork / Fiverr)" to "صلاحیت کے مطابق گرافکس، ویب، ٹرانسلیشن یا ڈیٹا کا کام براہ راست عالمی کلائنٹس کو فراہم کریں۔",
        "ڈیجیٹل پروڈکٹس اور ٹیمپلیٹس" to "کینوا ٹیمپلیٹس، نوٹس یا ریزیومے ڈیزائن کر کے آن لائن فروخت کریں۔",
        "یوٹیوب اور سوشل مواد" to "معلوماتی ویڈیوز، ٹیک ٹپس یا ٹیوٹوریلز بنائیں اور اشتہارات و اسپانسر شپ سے کمائیں۔",
        "ریموٹ اسسٹنٹ اور کنسلٹنگ" to "غیر ملکی کمپنیوں کے لیے کسٹمر سپورٹ یا ای میل مینجمنٹ ریموٹلی انجام دیں۔"
      )
    } else {
      listOf(
        "Freelance Marketplaces (Upwork / Fiverr)" to "Deliver verified client projects in design, writing, coding, or translation directly with escrow safety.",
        "Digital Products & Templates" to "Create Canva templates, Notion dashboards, or design assets once and sell repeatedly.",
        "Educational Content & Media" to "Publish YouTube Shorts or tutorials around tech and earn via ad revenue and brand deals.",
        "Remote Virtual Assistance" to "Support overseas businesses with scheduling, email support, and data entry from home."
      )
    }

    channels.forEach { (title, description) ->
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = description,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 18.sp
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Golden safety rule notice
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
        Icon(
          Icons.Default.Info,
          contentDescription = null,
          tint = Color(0xFFDC2626),
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (language.isUrdu) 
            "سنہری اصول: حقیقی جاب میں آپ کو کام کرنے پر پیسے ملتے ہیں، نوکری حاصل کرنے کے لیے پیسے دینے نہیں پڑتے!" 
          else 
            "Golden Rule: Real jobs PAY you for work done. Legitimate employers NEVER ask you to deposit money first!",
          fontSize = 12.sp,
          color = Color(0xFF991B1B),
          lineHeight = 17.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}
