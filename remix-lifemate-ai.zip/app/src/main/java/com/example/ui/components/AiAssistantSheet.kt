package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.AiFeatureColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiAssistantSheet(
  language: AppLanguage,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var promptText by remember { mutableStateOf("") }
  var isThinking by remember { mutableStateOf(false) }
  var assistantResponse by remember {
    mutableStateOf(
      if (language.isUrdu) {
        "السلام علیکم! میں آپ کا لائف میٹ اے آئی معاون ہوں۔ آپ مجھ سے آن لائن کمائی، نئی مہارتیں، بجٹ یا کسی بھی مشکوک پیشکش کے بارے میں مشورہ لے سکتے ہیں۔ نیچے دیے گئے سوالات میں سے چنیں یا اپنا سوال لکھیں!"
      } else {
        "Hello! I am your LifeMate AI Assistant. You can ask me about online earning, modern skills, smart budgeting, or checking suspicious offers. Pick a quick prompt below or type your question!"
      }
    )
  }

  val coroutineScope = rememberCoroutineScope()

  val samplePrompts = if (language.isUrdu) {
    listOf(
      "فری لانسنگ کیسے شروع کروں؟",
      "آن لائن دھوکے سے کیسے بچیں؟",
      "طالب علموں کے لیے بجٹ بنانے کا اصول",
      "۲۰۲۵ میں سب سے زیادہ معاوضے والی اسکلز",
    )
  } else {
    listOf(
      "How to start freelancing with zero capital?",
      "How to spot online scam jobs?",
      "Simple 50/30/20 budget breakdown",
      "Top high-income tech skills to learn",
    )
  }

  fun generateAnswer(query: String) {
    coroutineScope.launch {
      isThinking = true
      delay(600) // Realistic responsive feel
      assistantResponse = if (language.isUrdu) {
        when {
          query.contains("فری لانس") || query.contains("شروع") ->
            "فری لانسنگ شروع کرنے کے بنیادی ۳ مراحل:\n۱. ایک مخصوص مہارت منتخب کریں (جیسے گرافک ڈیزائن، ویب سائٹ یا کانٹینٹ رائٹنگ)۔\n۲. کم از کم ۳ سے ۵ بہترین نمونے تیار کر کے پورٹ فولیو بنائیں تاکہ کلائنٹ کو اعتماد حاصل ہو۔\n۳. Upwork یا Fiverr پر مکمل پروفائل بنائیں اور سنجیدہ پروپوزل لکھیں۔ کبھی بھی جاب حاصل کرنے کے لیے کوئی فیس نہ دیں!"
          query.contains("دھوکے") || query.contains("اسکیم") ->
            "آن لائن فراڈ سے بچنے کی اہم نشانیاں:\n• اگر کوئی کام شروع کرنے سے پہلے 'رجسٹریشن فیس' یا سیکیورٹی ڈپازٹ مانگے تو یہ ۱۰۰٪ فراڈ ہے۔\n• یوٹیوب ویڈیوز لائک کرنے پر لاکھوں روپے کمانے کے دعوے سراسر جھوٹے ہیں۔\n• ہمیشہ پلیٹ فارم کے اندر محفوظ طریقہ کار سے ادائیگی لیں۔"
          query.contains("بجٹ") ->
            "۵۰/۳۰/۲۰ کا بجٹ فارمولا:\n• ۵۰٪ ضروریات پر (کرایہ، راشن، یوٹیلیٹی بلز)۔\n• ۳۰٪ خواہشات اور ذاتی اخراجات پر۔\n• ۲۰٪ ہنگامی فنڈ اور بچت کے لیے محفوظ رکھیں۔"
          else ->
            "آپ کا سوال موصول ہوا: '$query'۔\n\nلائف میٹ اے آئی مشورہ: ہمیشہ مستقل مزاجی اور تصدیق شدہ معلومات کے ساتھ آگے بڑھیں۔ اگر آپ کو کسی خاص شعبے میں تفصیل چاہیے تو بتائیں۔"
        }
      } else {
        when {
          query.contains("freelanc", ignoreCase = true) || query.contains("capital", ignoreCase = true) ->
            "3 Proven Steps to Start Freelancing with Zero Budget:\n1. Master 1 specific high-demand niche (e.g. UI/UX design, WordPress/Next.js, or Video Editing).\n2. Build a proof-of-work portfolio with 3 polished sample projects.\n3. Create an optimized Upwork & LinkedIn profile, targeting low-competition specialized tags. Never pay upfront fees to get work!"
          query.contains("scam", ignoreCase = true) || query.contains("spot", ignoreCase = true) ->
            "Top Red Flags for Scam Online Jobs:\n• Requests upfront 'registration/insurance' deposits via crypto or mobile wallet.\n• Promises huge guaranteed daily returns ($100+/day for clicking or liking videos).\n• Unofficial communication channels solely on Telegram/WhatsApp with no corporate presence."
          query.contains("budget", ignoreCase = true) ->
            "The 50/30/20 Smart Budget Method:\n• 50% for Needs: Rent, essential groceries, utilities, and transport.\n• 30% for Wants: Hobbies, leisure, dining, personal items.\n• 20% for Wealth: Emergency fund (3-6 months), investments, and debt reduction."
          else ->
            "Guidance for '$query':\n\nFocus on verified sources, incremental daily consistency, and protect your private credentials at all times. LifeMate AI recommends setting a clear daily milestone for this goal!"
        }
      }
      isThinking = false
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(AiFeatureColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = AiFeatureColor,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (language.isUrdu) "اے آئی اسسٹنٹ" else "AI Assistant",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (language.isUrdu) "تیز رفتار اور سمارٹ حل" else "Instant intelligent guidance",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("ai_sheet_close_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close")
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Assistant Response Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(AiFeatureColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (language.isUrdu) "لائف میٹ جواب:" else "LifeMate Advisor:",
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp,
              color = AiFeatureColor
            )
          }
          if (isThinking) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              strokeWidth = 2.dp,
              color = AiFeatureColor
            )
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = assistantResponse,
          style = MaterialTheme.typography.bodyMedium,
          lineHeight = 22.sp,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Quick Prompts
    Text(
      text = if (language.isUrdu) "فوری سوالات (ٹیپ کریں):" else "Quick suggested prompts:",
      style = MaterialTheme.typography.labelLarge,
      fontWeight = FontWeight.SemiBold,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(modifier = Modifier.height(8.dp))

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      samplePrompts.forEach { prompt ->
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          modifier = Modifier
            .clickable {
              promptText = prompt
              generateAnswer(prompt)
            }
        ) {
          Text(
            text = prompt,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // User input row
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      OutlinedTextField(
        value = promptText,
        onValueChange = { promptText = it },
        placeholder = {
          Text(
            if (language.isUrdu) "اپنا سوال یہاں لکھیں..." else "Ask any question...",
            fontSize = 14.sp
          )
        },
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
          .weight(1f)
          .testTag("ai_prompt_input"),
        singleLine = true,
      )
      Spacer(modifier = Modifier.width(8.dp))
      Button(
        onClick = {
          if (promptText.isNotBlank()) {
            generateAnswer(promptText)
          }
        },
        enabled = promptText.isNotBlank() && !isThinking,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = AiFeatureColor),
        modifier = Modifier
          .size(48.dp)
          .testTag("ai_send_button"),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.Send,
          contentDescription = "Send",
          tint = Color.White,
          modifier = Modifier.size(20.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))
  }
}
