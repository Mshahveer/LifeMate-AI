package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.ScamFeatureColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ScanResult(
  val riskScore: Int, // 0 - 100
  val level: String, // SAFE, CAUTION, HIGH_RISK
  val redFlags: List<String>,
  val advice: String,
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScamCheckerSheet(
  language: AppLanguage,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var textToAnalyze by remember { mutableStateOf("") }
  var isScanning by remember { mutableStateOf(false) }
  var scanResult by remember { mutableStateOf<ScanResult?>(null) }
  val coroutineScope = rememberCoroutineScope()

  val sampleTests = if (language.isUrdu) {
    listOf(
      "ویڈیو لائک کر کے روزانہ ۵۰۰۰ کمائیں، صرف ۱۰۰۰ فیس دیں" to 95,
      "ڈبل منافع کرپٹو اسکیم، ابھی جوائن کریں اور فوری بونس پائیں" to 90,
      "اپ ورک پر باضابطہ کانٹریکٹ کے تحت ویب سائٹ کا کام" to 10
    )
  } else {
    listOf(
      "Earn $500/day liking YouTube videos, send $20 registration fee" to 95,
      "Double your Bitcoin in 24 hours guaranteed investment bot" to 92,
      "Official freelance job on Upwork with escrow milestone payment" to 10
    )
  }

  fun performScan(input: String) {
    if (input.isBlank()) return
    coroutineScope.launch {
      isScanning = true
      delay(700)

      val lower = input.lowercase()
      var score = 15
      val flags = mutableListOf<String>()

      // Keyword detection
      if (lower.contains("fee") || lower.contains("deposit") || lower.contains("فیس") || lower.contains("ڈپازٹ") || lower.contains("send")) {
        score += 35
        flags.add(if (language.isUrdu) "شروعاتی فیس یا رقم کا مطالبہ" else "Requests upfront fee or deposit")
      }
      if (lower.contains("guarantee") || lower.contains("double") || lower.contains("daily") || lower.contains("گارنٹی") || lower.contains("روزانہ") || lower.contains("ڈبل")) {
        score += 25
        flags.add(if (language.isUrdu) "غیر حقیقی یا حیران کن منافع کے دعوے" else "Unrealistic guaranteed daily returns")
      }
      if (lower.contains("telegram") || lower.contains("whatsapp") || lower.contains("ٹیلیگرام") || lower.contains("واٹس ایپ")) {
        score += 15
        flags.add(if (language.isUrdu) "صرف غیر محفوظ نجی چیٹ کے ذریعے رابطہ" else "Restricted to unverified private messenger")
      }
      if (lower.contains("crypto") || lower.contains("bitcoin") || lower.contains("کرپٹو")) {
        score += 15
        flags.add(if (language.isUrdu) "غیر ریگولیٹڈ کرپٹو یا انویسٹمنٹ سکیم" else "Unregulated crypto/investment scheme")
      }
      if (lower.contains("upwork") || lower.contains("fiverr") || lower.contains("escrow") || lower.contains("اپ ورک")) {
        score = (score - 40).coerceAtLeast(5)
      }

      val finalScore = score.coerceIn(5, 98)
      val level = when {
        finalScore >= 70 -> "HIGH_RISK"
        finalScore >= 35 -> "CAUTION"
        else -> "SAFE"
      }

      val advice = if (language.isUrdu) {
        when (level) {
          "HIGH_RISK" -> "خطرناک فراڈ! یہ پیغام سو فیصد جعلی ہے۔ ہرگز کوئی رقم یا شناختی دستاویز نہ بھیجیں اور اس نمبر کو فوری بلاک کریں۔"
          "CAUTION" -> "احتیاط برتیں! اس پیشکش میں مشکوک علامات موجود ہیں۔ کوئی ذاتی معلومات نہ دیں جب تک کمپنی کی باضابطہ تصدیق نہ ہو۔"
          else -> "محفوظ معلوم ہوتا ہے۔ عام حفاظتی تدابیر اختیار کریں اور باضابطہ پلیٹ فارم کے ذریعے ہی لین دین کریں۔"
        }
      } else {
        when (level) {
          "HIGH_RISK" -> "HIGH DANGER! This offer matches confirmed scam patterns. Never transfer money, share OTPs, or send IDs. Block sender immediately."
          "CAUTION" -> "PROCEED WITH CAUTION. Multiple suspicious factors identified. Independently verify the company domain before responding."
          else -> "APPEARS SAFE. Matches standard legitimate workflows. Still ensure payments stay within verified escrow protection."
        }
      }

      scanResult = ScanResult(
        riskScore = finalScore,
        level = level,
        redFlags = if (flags.isEmpty()) listOf(if (language.isUrdu) "کوئی بڑا خطرہ نہیں ملا" else "No major red flags detected") else flags,
        advice = advice
      )
      isScanning = false
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 20.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(ScamFeatureColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = ScamFeatureColor,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (language.isUrdu) "اسکیم چیکر" else "AI Scam Checker",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (language.isUrdu) "مشکوک پیغامات اور لنکس کی جانچ" else "Verify fraudulent offers & links",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("scam_sheet_close_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close")
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Text Input for scan
    OutlinedTextField(
      value = textToAnalyze,
      onValueChange = { textToAnalyze = it },
      label = {
        Text(
          if (language.isUrdu) "میسج، پیشکش یا لنک یہاں چسپاں کریں" else "Paste message, job offer or link",
          fontSize = 13.sp
        )
      },
      placeholder = {
        Text(
          if (language.isUrdu) "مثال: 'گھر بیٹھے روزانہ ہزاروں کمائیں، فیس جمع کروائیں'..." else "e.g., 'Earn $500/day by liking videos, deposit fee'...",
          fontSize = 12.sp
        )
      },
      minLines = 3,
      maxLines = 4,
      shape = RoundedCornerShape(16.dp),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("scam_input_field"),
    )

    Spacer(modifier = Modifier.height(10.dp))

    // Quick sample tests
    Text(
      text = if (language.isUrdu) "فوری آزمائشی نمونے:" else "Quick test samples:",
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(6.dp))

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      sampleTests.forEach { (sample, _) ->
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier.clickable {
            textToAnalyze = sample
            performScan(sample)
          }
        ) {
          Text(
            text = sample.take(35) + "...",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    Button(
      onClick = { performScan(textToAnalyze) },
      enabled = textToAnalyze.isNotBlank() && !isScanning,
      shape = RoundedCornerShape(12.dp),
      colors = ButtonDefaults.buttonColors(containerColor = ScamFeatureColor),
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .testTag("scam_analyze_button")
    ) {
      if (isScanning) {
        CircularProgressIndicator(
          modifier = Modifier.size(20.dp),
          color = Color.White,
          strokeWidth = 2.dp
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(if (language.isUrdu) "جانچ ہو رہی ہے..." else "Analyzing Pattern...")
      } else {
        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (language.isUrdu) "فراڈ کی جانچ کریں" else "Check for Scam Risk",
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Result Display
    AnimatedVisibility(visible = scanResult != null) {
      scanResult?.let { res ->
        val resultColor = when (res.level) {
          "HIGH_RISK" -> Color(0xFFDC2626)
          "CAUTION" -> Color(0xFFD97706)
          else -> Color(0xFF059669)
        }
        val resultBg = when (res.level) {
          "HIGH_RISK" -> Color(0xFFFEF2F2)
          "CAUTION" -> Color(0xFFFFFBEB)
          else -> Color(0xFFECFDF5)
        }

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = resultBg),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = when (res.level) {
                    "HIGH_RISK" -> Icons.Default.Dangerous
                    "CAUTION" -> Icons.Default.Warning
                    else -> Icons.Default.GppGood
                  },
                  contentDescription = null,
                  tint = resultColor,
                  modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (language.isUrdu) {
                    when (res.level) {
                      "HIGH_RISK" -> "خطرناک فراڈ کا امکان!"
                      "CAUTION" -> "مشکوک علامات!"
                      else -> "محفوظ معلوم ہوتا ہے"
                    }
                  } else {
                    when (res.level) {
                      "HIGH_RISK" -> "HIGH SCAM RISK!"
                      "CAUTION" -> "SUSPICIOUS OFFER!"
                      else -> "PROBABLY SAFE"
                    }
                  },
                  fontWeight = FontWeight.Bold,
                  color = resultColor,
                  fontSize = 15.sp
                )
              }
              Text(
                text = "${res.riskScore}%",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp,
                color = resultColor
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
              progress = { res.riskScore / 100f },
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
              color = resultColor,
              trackColor = resultColor.copy(alpha = 0.2f),
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = if (language.isUrdu) "شناخت شدہ علامات:" else "Detected Indicators:",
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp,
              color = resultColor
            )
            res.redFlags.forEach { flag ->
              Text(
                text = "• $flag",
                fontSize = 12.sp,
                color = Color(0xFF1F2937),
                modifier = Modifier.padding(vertical = 2.dp)
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
              text = res.advice,
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium,
              color = Color(0xFF111827),
              lineHeight = 18.sp
            )
          }
        }
      }
    }
  }
}
