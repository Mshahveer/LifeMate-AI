package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.GoalsFeatureColor

data class DailyGoal(
  val id: Long,
  val titleEn: String,
  val titleUr: String,
  var isCompleted: Boolean = false,
)

@Composable
fun DailyGoalsSheet(
  language: AppLanguage,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val goals = remember {
    mutableStateListOf(
      DailyGoal(1, "Practice a new skill for 30 minutes", "۳۰ منٹ تک نئی مہارت کی پریکٹس کریں", true),
      DailyGoal(2, "Review daily expenses & log budget", "روزمرہ کے اخراجات کا جائزہ لیں", false),
      DailyGoal(3, "Read 1 educational or career article", "ایک تعلیمی یا کیریئر آرٹیکل پڑھیں", true),
      DailyGoal(4, "Drink 2.5 Liters of clean water", "ڈھائی لیٹر پانی پئیں اور صحت کا خیال رکھیں", false),
      DailyGoal(5, "Plan priority tasks for tomorrow", "کل کے اہم کاموں کی فہرست ترتیب دیں", false),
    )
  }

  var newGoalText by remember { mutableStateOf("") }

  val completedCount = goals.count { it.isCompleted }
  val totalCount = goals.size
  val progress = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(GoalsFeatureColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircleOutline,
            contentDescription = null,
            tint = GoalsFeatureColor,
            modifier = Modifier.size(24.dp)
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = if (language.isUrdu) "روزانہ کے اہداف" else "Daily Goals",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
          Text(
            text = if (language.isUrdu) "عادتیں بنائیں اور وقت کا صحیح استعمال کریں" else "Build positive habits & productivity",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.testTag("goals_sheet_close_button")
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close")
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Progress Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = GoalsFeatureColor.copy(alpha = 0.1f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (language.isUrdu) "آج کی مجموعی پیش رفت" else "Today's Overall Progress",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = GoalsFeatureColor
          )
          Text(
            text = "$completedCount / $totalCount (${(progress * 100).toInt()}%)",
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
            color = GoalsFeatureColor
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { progress },
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = GoalsFeatureColor,
          trackColor = GoalsFeatureColor.copy(alpha = 0.2f),
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Add Goal Input
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = newGoalText,
        onValueChange = { newGoalText = it },
        placeholder = {
          Text(
            if (language.isUrdu) "نیا ہدف شامل کریں..." else "Add new goal...",
            fontSize = 13.sp
          )
        },
        shape = RoundedCornerShape(12.dp),
        singleLine = true,
        modifier = Modifier
          .weight(1f)
          .testTag("goal_input_field")
      )
      Spacer(modifier = Modifier.width(8.dp))
      Button(
        onClick = {
          if (newGoalText.isNotBlank()) {
            goals.add(
              DailyGoal(
                id = System.currentTimeMillis(),
                titleEn = newGoalText.trim(),
                titleUr = newGoalText.trim(),
                isCompleted = false
              )
            )
            newGoalText = ""
          }
        },
        enabled = newGoalText.isNotBlank(),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = GoalsFeatureColor),
        modifier = Modifier.testTag("add_goal_button")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add")
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Goals List
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.weight(1f, fill = false)
    ) {
      items(goals, key = { it.id }) { goal ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (goal.isCompleted) 
              MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) 
            else 
              MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
          ),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              val index = goals.indexOf(goal)
              if (index >= 0) {
                goals[index] = goal.copy(isCompleted = !goal.isCompleted)
              }
            }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = goal.isCompleted,
              onCheckedChange = { checked ->
                val index = goals.indexOf(goal)
                if (index >= 0) {
                  goals[index] = goal.copy(isCompleted = checked)
                }
              },
              colors = CheckboxDefaults.colors(checkedColor = GoalsFeatureColor)
            )
            Text(
              text = if (language.isUrdu) goal.titleUr else goal.titleEn,
              fontSize = 14.sp,
              textDecoration = if (goal.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
              color = if (goal.isCompleted) 
                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) 
              else 
                MaterialTheme.colorScheme.onSurface,
              modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
            )
            IconButton(
              onClick = { goals.remove(goal) }
            ) {
              Icon(
                Icons.Default.DeleteOutline,
                contentDescription = "Delete",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }
    }
  }
}
