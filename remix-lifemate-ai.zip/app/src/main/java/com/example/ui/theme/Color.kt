package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo / Deep Blue
val IndigoPrimary = Color(0xFF1E3A8A)
val IndigoLight = Color(0xFF3B82F6)
val IndigoDark = Color(0xFF172554)

// Accents for the 6 Core Features
val AiFeatureColor = Color(0xFF7C3AED) // Purple/Violet
val SkillsFeatureColor = Color(0xFF0D9488) // Teal/Emerald
val EarnFeatureColor = Color(0xFFD97706) // Warm Amber/Gold
val ScamFeatureColor = Color(0xFFE11D48) // Rose/Crimson
val GoalsFeatureColor = Color(0xFF0284C7) // Sky Blue
val BudgetFeatureColor = Color(0xFF059669) // Green/Emerald

// Surface and background palettes
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
