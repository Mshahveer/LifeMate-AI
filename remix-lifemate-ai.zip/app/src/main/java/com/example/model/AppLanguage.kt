package com.example.model

enum class AppLanguage(
  val code: String,
  val label: String,
  val flag: String,
) {
  ENGLISH(code = "en", label = "English", flag = "🇬🇧"),
  URDU(code = "ur", label = "اردو", flag = "🇵🇰");

  val isUrdu: Boolean
    get() = this == URDU
}

object Translations {
  fun appTitle(lang: AppLanguage) = if (lang.isUrdu) "لائف میٹ اے آئی" else "LifeMate AI"
  fun appTagline(lang: AppLanguage) = if (lang.isUrdu) "آپ کا ذہین اور بااعتماد روزمرہ کا رہنما" else "Your Smart Everyday Companion"
  fun greeting(lang: AppLanguage) = if (lang.isUrdu) "خوش آمدید! آج آپ کیا کرنا چاہتے ہیں؟" else "Welcome! What would you like to do today?"
  fun dailyTipTitle(lang: AppLanguage) = if (lang.isUrdu) "آج کی سنہری بات" else "Daily Wisdom"
  fun dailyTip(lang: AppLanguage) = if (lang.isUrdu) 
    "مستقل مزاجی چھوٹی کامیابیوں کو بڑی منزل میں بدل دیتی ہے۔ روزانہ کچھ نیا سیکھیں!" 
  else 
    "Small consistent steps lead to massive achievements. Learn something new every day!"

  fun servicesHeader(lang: AppLanguage) = if (lang.isUrdu) "بنیادی خدمات" else "Explore Services"
  fun servicesSubHeader(lang: AppLanguage) = if (lang.isUrdu) "اپنی ضرورت کے مطابق منتخب کریں" else "Select any tool below to get started"

  // Feature 1: AI Assistant
  fun aiTitle(lang: AppLanguage) = if (lang.isUrdu) "اے آئی معاون" else "AI Assistant"
  fun aiDesc(lang: AppLanguage) = if (lang.isUrdu) "ذہین رہنمائی اور فوری جوابات" else "Smart answers & personalized advice"

  // Feature 2: Learn Skills
  fun skillsTitle(lang: AppLanguage) = if (lang.isUrdu) "مہارتیں سیکھیں" else "Learn Skills"
  fun skillsDesc(lang: AppLanguage) = if (lang.isUrdu) "جدید ٹیکنالوجی اور فری لانسنگ اسکلز" else "High-income tech & freelance courses"

  // Feature 3: Earn Online
  fun earnTitle(lang: AppLanguage) = if (lang.isUrdu) "آن لائن کمائیں" else "Earn Online"
  fun earnDesc(lang: AppLanguage) = if (lang.isUrdu) "حقیقی اور تصدیق شدہ طریقوں سے آمدنی" else "Verified pathways to work from home"

  // Feature 4: Scam Checker
  fun scamTitle(lang: AppLanguage) = if (lang.isUrdu) "اسکیم چیکر" else "Scam Checker"
  fun scamDesc(lang: AppLanguage) = if (lang.isUrdu) "مشکوک پیغامات اور جعلی جابز کی جانچ" else "Verify fraudulent links & fake offers"

  // Feature 5: Daily Goals
  fun goalsTitle(lang: AppLanguage) = if (lang.isUrdu) "روزانہ کے اہداف" else "Daily Goals"
  fun goalsDesc(lang: AppLanguage) = if (lang.isUrdu) "عادات بنائیں اور پیداواری صلاحیت بڑھائیں" else "Build habits & track daily milestones"

  // Feature 6: Budget Planner
  fun budgetTitle(lang: AppLanguage) = if (lang.isUrdu) "بجٹ پلانر" else "Budget Planner"
  fun budgetDesc(lang: AppLanguage) = if (lang.isUrdu) "آمدن، اخراجات اور بچت کا حساب" else "Track expenses & grow your savings"

  fun openButton(lang: AppLanguage) = if (lang.isUrdu) "کھولیں" else "Open"
  fun closeButton(lang: AppLanguage) = if (lang.isUrdu) "بند کریں" else "Close"
  fun languageSwitchPrompt(lang: AppLanguage) = if (lang.isUrdu) "زبان تبدیل کریں" else "Language"
  fun safetyGuarantee(lang: AppLanguage) = if (lang.isUrdu) "۱۰۰٪ محفوظ • سادہ اور تیز رفتار" else "100% Private & Fast • Built for Success"
}
