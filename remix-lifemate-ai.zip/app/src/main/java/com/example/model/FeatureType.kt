package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.AiFeatureColor
import com.example.ui.theme.BudgetFeatureColor
import com.example.ui.theme.EarnFeatureColor
import com.example.ui.theme.GoalsFeatureColor
import com.example.ui.theme.ScamFeatureColor
import com.example.ui.theme.SkillsFeatureColor

enum class FeatureType(
  val testTag: String,
  val icon: ImageVector,
  val accentColor: Color,
  val badgeTextEn: String,
  val badgeTextUr: String,
) {
  AI_ASSISTANT(
    testTag = "ai_assistant_button",
    icon = Icons.Default.AutoAwesome,
    accentColor = AiFeatureColor,
    badgeTextEn = "Smart AI",
    badgeTextUr = "ذہین مدد",
  ),
  LEARN_SKILLS(
    testTag = "learn_skills_button",
    icon = Icons.Default.School,
    accentColor = SkillsFeatureColor,
    badgeTextEn = "In Demand",
    badgeTextUr = "مطلوبہ ہنر",
  ),
  EARN_ONLINE(
    testTag = "earn_online_button",
    icon = Icons.Default.TrendingUp,
    accentColor = EarnFeatureColor,
    badgeTextEn = "Verified",
    badgeTextUr = "تصدیق شدہ",
  ),
  SCAM_CHECKER(
    testTag = "scam_checker_button",
    icon = Icons.Default.Security,
    accentColor = ScamFeatureColor,
    badgeTextEn = "Safety First",
    badgeTextUr = "حفاظت",
  ),
  DAILY_GOALS(
    testTag = "daily_goals_button",
    icon = Icons.Default.CheckCircleOutline,
    accentColor = GoalsFeatureColor,
    badgeTextEn = "Habits",
    badgeTextUr = "اہداف",
  ),
  BUDGET_PLANNER(
    testTag = "budget_planner_button",
    icon = Icons.Default.AccountBalanceWallet,
    accentColor = BudgetFeatureColor,
    badgeTextEn = "Finance",
    badgeTextUr = "مالیات",
  );

  fun getTitle(lang: AppLanguage): String = when (this) {
    AI_ASSISTANT -> Translations.aiTitle(lang)
    LEARN_SKILLS -> Translations.skillsTitle(lang)
    EARN_ONLINE -> Translations.earnTitle(lang)
    SCAM_CHECKER -> Translations.scamTitle(lang)
    DAILY_GOALS -> Translations.goalsTitle(lang)
    BUDGET_PLANNER -> Translations.budgetTitle(lang)
  }

  fun getDescription(lang: AppLanguage): String = when (this) {
    AI_ASSISTANT -> Translations.aiDesc(lang)
    LEARN_SKILLS -> Translations.skillsDesc(lang)
    EARN_ONLINE -> Translations.earnDesc(lang)
    SCAM_CHECKER -> Translations.scamDesc(lang)
    DAILY_GOALS -> Translations.goalsDesc(lang)
    BUDGET_PLANNER -> Translations.budgetDesc(lang)
  }

  fun getBadge(lang: AppLanguage): String = if (lang.isUrdu) badgeTextUr else badgeTextEn
}
